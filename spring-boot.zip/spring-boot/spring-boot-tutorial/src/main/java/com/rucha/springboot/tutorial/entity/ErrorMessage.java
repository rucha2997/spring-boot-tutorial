package com.rucha.springboot.tutorial.entity;

import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.http.HttpStatus;

@Data
@NoArgsConstructor
public class ErrorMessage {

    private HttpStatus status;
    private String message;

    public ErrorMessage(HttpStatus notFound, String message) {
    }
}

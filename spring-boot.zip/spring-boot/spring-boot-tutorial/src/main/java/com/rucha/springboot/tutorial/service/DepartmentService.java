package com.rucha.springboot.tutorial.service;

import com.rucha.springboot.tutorial.entity.Department;
import com.rucha.springboot.tutorial.error.DepartmentException;

import java.util.List;

public interface DepartmentService {
    public Department saveDepartment(Department department);

    public List<Department> fetchDepartmentList();

    public Department fetchDepartmentId(Long departmentId) throws DepartmentException;

    public void deleteDepartment(Long departmentId);

    public Department updateDepartment(Long departmentId, Department department);

    public Department fetchDepartmentByName(String departmentName);
}

package com.rucha.springboot.tutorial.controller;

import com.rucha.springboot.tutorial.entity.Department;
import com.rucha.springboot.tutorial.error.DepartmentException;
import com.rucha.springboot.tutorial.service.DepartmentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
public class DepartmentController {

    @Autowired
    private DepartmentService departmentService;

    private final Logger LOGGER = LoggerFactory.getLogger(DepartmentController.class);

    @PostMapping("/department")
    public Department saveDepartment(@Valid @RequestBody Department department){
        LOGGER.info("Inside save department");
        return departmentService.saveDepartment(department);
    }

    @GetMapping("/department")
    public List<Department> fetchDepartmentList(){
        return departmentService.fetchDepartmentList();
    }

    @GetMapping("/department/{id}")
    public Department fetchDepartmentById( @PathVariable("id") Long departmentId) throws DepartmentException {
        return departmentService.fetchDepartmentId(departmentId);
    }

    @DeleteMapping("/department/{id}")
    public String deleteDepartment(@PathVariable("id") Long departmentId){
        departmentService.deleteDepartment(departmentId);
        return "deleted successfully";
    }

    @PutMapping("/department/{id}")
    public Department updateDepartment(@PathVariable("id") Long departmentId,@RequestBody Department department ){
        return departmentService.updateDepartment(departmentId,department);

    }

    @GetMapping("/department/name/{name}")
    public Department fetchDepartmentByName( @PathVariable("name") String departmentName){
        return departmentService.fetchDepartmentByName(departmentName);

    }




}
